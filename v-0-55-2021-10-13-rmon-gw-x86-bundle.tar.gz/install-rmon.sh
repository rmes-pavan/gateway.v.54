#!/bin/sh

fnCopyfile()
{
    # $1 = from file
    # $2 = to file
    # $3 = 1 --> exit onfail; 0 --> don't exit onfail
    # $4 = 1 --> set exec permissions; 0 --> don't set exec permissions
    #echo "cp $1 $2 $3"
    cp -f $1 $2
    if [ $? -ne 0 ]; then
        if [ $3 = 1 ]; then
            echo "FATAL ERROR: Unable to copy [$1] --> [$2]. Exiting..."
            exit 0
        else
            echo "ERROR: Unable to copy [$1] --> [$2]. Not Exiting..."
        fi
    else
        if [ $4 = 1 ]; then
            chmod a+x $2
        fi
    fi
}

ABSOLUTE_PATH_TO_THIS_SCRIPT=$(readlink -f "$0")
BASEDIR=$(dirname "$ABSOLUTE_PATH_TO_THIS_SCRIPT")
BUILD_TARGET="builds/build-target"

#
# check where this script is running?
THISARCH="x86"
if echo "`uname -m`" | grep -q "arm"
then
  echo "This is ARM machine"
  THISARCH="arm"
  BUILD_TARGET="builds/arm-build-target"
else 
  echo "This is x86 machine"
fi

SRCBINSDIR="$BASEDIR/$BUILD_TARGET/bins"
SRCCFGDIR="$BASEDIR/$BUILD_TARGET/cfg"
SRCPROTCFGDIR="$BASEDIR/$BUILD_TARGET/cfg/protcfg"
SRCREDISCFGDIR="$BASEDIR/$BUILD_TARGET/cfg/redis"
SRCSCRIPTSDIR="$BASEDIR/$BUILD_TARGET/scripts"


# check if the script is running with sudo privilege?
if [ "`id -u`" = "0" ]
then
  echo "Running this script in sudo mode"
else 
  echo "Please run this script as sudo [sudo <script.sh>]!"
  exit 0
fi

echo "Installing Gateway Software of Rugged Monitoring Company..."
nowdate=$(date)


# Note: At this point we are running this script as root user.
# The original user can be obtained with $SUDO_USER env parameter
#HOMEDIR=`echo ~` # This will give /root as the response. But we want the original user
HOMEDIR=`eval echo ~$SUDO_USER`
echo "Home Dir = $HOMEDIR"


#FIFODIR="/tmp/fifo-rmon"
ROOTDIR="$HOMEDIR/gw-rmon"
TMPDIR="$HOMEDIR/gw-rmon/tmp"
BUNDLESDIR="$HOMEDIR/gw-rmon/bundles"
BUNDLESCFGDIR="$HOMEDIR/gw-rmon/bundles/cfg"
BUNDLESSWDIR="$HOMEDIR/gw-rmon/bundles/sw"
BINSDIR="$HOMEDIR/gw-rmon/bins"
REDISDBDIR="$HOMEDIR/gw-rmon/db"
OFFLINEDATADIR="$HOMEDIR/gw-rmon/db/offlinedata"
PDDATADIR="$HOMEDIR/gw-rmon/db/pddata"
SCRIPTSDIR="$HOMEDIR/gw-rmon/scripts"
CFGDIR="$HOMEDIR/gw-rmon/cfg"
PDCFGDIR="$HOMEDIR/gw-rmon/cfg/pd"
PROTCFGDIR="$HOMEDIR/gw-rmon/cfg/protcfg"
TEMPLATES_PROTCFGDIR="$HOMEDIR/gw-rmon/cfg/protcfg/templates"
EDITABLE_PROTCFGDIR="$HOMEDIR/gw-rmon/cfg/protcfg/editable"
FINAL_PROTCFGDIR="$HOMEDIR/gw-rmon/cfg/protcfg/final"
AUTOGEN_PROTCFGDIR="$HOMEDIR/gw-rmon/cfg/protcfg/auto-generated"
REDISCFGDIR="$CFGDIR/redis"
MQTTCFGFILEDIR="$CFGDIR/mqtt"
FULLSTOPFILE="$TMPDIR/full-stop-rmon"
STOPFILE="$TMPDIR/stop-rmon"

#echo "Create necessary folders"
test -z "$ROOTDIR"              || mkdir -p -- "$ROOTDIR"
test -z "$TMPDIR"               || mkdir -p -- "$TMPDIR"
test -z "$BUNDLESCFGDIR"        || mkdir -p -- "$BUNDLESCFGDIR"
test -z "$BUNDLESSWDIR"         || mkdir -p -- "$BUNDLESSWDIR"
test -z "$BINSDIR"              || mkdir -p -- "$BINSDIR"
test -z "$REDISDBDIR"           || mkdir -p -- "$REDISDBDIR"
test -z "$OFFLINEDATADIR"       || mkdir -p -- "$OFFLINEDATADIR"
test -z "$PDDATADIR"            || mkdir -p -- "$PDDATADIR"
test -z "$SCRIPTSDIR"           || mkdir -p -- "$SCRIPTSDIR"
test -z "$CFGDIR"               || mkdir -p -- "$CFGDIR"
test -z "$PDCFGDIR"             || mkdir -p -- "$PDCFGDIR"
test -z "$PROTCFGDIR"           || mkdir -p -- "$PROTCFGDIR"
test -z "$TEMPLATES_PROTCFGDIR" || mkdir -p -- "$TEMPLATES_PROTCFGDIR"
test -z "$EDITABLE_PROTCFGDIR"  || mkdir -p -- "$EDITABLE_PROTCFGDIR"
test -z "$FINAL_PROTCFGDIR"     || mkdir -p -- "$FINAL_PROTCFGDIR"
test -z "$AUTOGEN_PROTCFGDIR"   || mkdir -p -- "$AUTOGEN_PROTCFGDIR"
test -z "$REDISCFGDIR"          || mkdir -p -- "$REDISCFGDIR"
test -z "$MQTTCFGFILEDIR"       || mkdir -p -- "$MQTTCFGFILEDIR"

# Try to stop rmon-gw processes
echo "1" > $FULLSTOPFILE
sleepctr=0
while [ $sleepctr -lt 6 ]
do
    if test -f "$FULLSTOPFILE"; then
        echo "Waiting while stopping rmon processes... ($sleepctr/6)..."
        sleep 1
        sleepctr=$((sleepctr+1))
    else
        #echo "File Gone!"
        break
    fi
done
rm $FULLSTOPFILE
killall redis-server
sleep 3
echo "Proceeding to install..."


USERBIN_FOLDER="/usr/local/bin"
USERSBIN_FOLDER="/usr/local/sbin"
USERLIB_FOLDER="/usr/local/lib"
if [ $THISARCH = "arm" ]; then
    USERBIN_FOLDER="/usr/sbin"
    USERSBIN_FOLDER="/usr/sbin"
    USERLIB_FOLDER="/usr/lib"
fi

# Copy the bin files
fnCopyfile $SRCBINSDIR/hlpr-rmon $BINSDIR/ 1 1
fnCopyfile $SRCBINSDIR/modc-rmon $BINSDIR/ 1 1
fnCopyfile $SRCBINSDIR/mods-rmon $BINSDIR/ 1 1
fnCopyfile $SRCBINSDIR/ciec61850-rmon $BINSDIR/ 1 1
if [ $THISARCH = "arm" ]; then
    echo "filesc and bridge-rmon are not being installed on arm machines!"
    fnCopyfile $SRCBINSDIR/vers-rmon $BINSDIR/ 1 1
    #fnCopyfile $SRCBINSDIR/vers-rmon $PROTCFGDIR/ 1 1
    rm -f $PROTCFGDIR/vers-rmon
    ln -s -f $BINSDIR/vers-rmon $PROTCFGDIR/vers-rmon
else
    fnCopyfile $SRCBINSDIR/filesc-rmon $BINSDIR/ 0 1
    fnCopyfile $SRCBINSDIR/bridge-rmon $BINSDIR/ 1 1
    fnCopyfile $SRCBINSDIR/vers-rmon $BINSDIR/ 1 1
    # We need vers-mon program to go to /home/uday/gw-rmon/cfg/protcfg/ folder also
    # This script is used to generate automatic configuration files
    #fnCopyfile $SRCBINSDIR/vers-rmon $PROTCFGDIR/ 1 1
    rm -f $PROTCFGDIR/vers-rmon
    ln -s -f $BINSDIR/vers-rmon $PROTCFGDIR/vers-rmon
    fnCopyfile $SRCBINSDIR/evers-rmon $BINSDIR/ 1 1
    #fnCopyfile $SRCBINSDIR/evers-rmon $PROTCFGDIR/ 1 1
    rm -f $PROTCFGDIR/evers-rmon
    ln -s -f $BINSDIR/evers-rmon $PROTCFGDIR/evers-rmon
    fnCopyfile $SRCBINSDIR/link-rmon $BINSDIR/ 1 1
    fnCopyfile $SRCBINSDIR/alarm-rmon $BINSDIR/ 1 1
    fnCopyfile $SRCBINSDIR/dblog-rmon $BINSDIR/ 1 1
    #fnCopyfile $SRCBINSDIR/calc-rmon $BINSDIR/ 1 1
fi
fnCopyfile $SRCBINSDIR/watchdog-rmon $BINSDIR/ 1 1

# redis bins
fnCopyfile $SRCBINSDIR/redis-server $USERBIN_FOLDER/ 1 1
fnCopyfile $SRCBINSDIR/redis-cli $USERBIN_FOLDER/ 1 1

# redis libs
fnCopyfile $SRCBINSDIR/libhiredis.so $USERLIB_FOLDER/libhiredis.so.1.0.0 1 1
ln -s -f $USERLIB_FOLDER/libhiredis.so.1.0.0 $USERLIB_FOLDER/libhiredis.so

# libiec61850
fnCopyfile $SRCBINSDIR/libiec61850.so $USERLIB_FOLDER/libiec61850.so 1 1

#cJSON
fnCopyfile $SRCBINSDIR/libcjson.so.1.7.14 $USERLIB_FOLDER/ 1 1
ln -s -f $USERLIB_FOLDER/libcjson.so.1.7.14 $USERLIB_FOLDER/libcjson.so.1
ln -s -f $USERLIB_FOLDER/libcjson.so.1 $USERLIB_FOLDER/libcjson.so

#mosquitto
if [ $THISARCH = "arm" ]; then
    echo "******* NOT installing mosquitto stuff as R501 Quebec team is already using an older version."
    echo "******* We will make use of it for now!"
else
    fnCopyfile $SRCBINSDIR/mosquitto $USERSBIN_FOLDER/ 1 1

    fnCopyfile $SRCBINSDIR/mosquitto_pub $USERBIN_FOLDER/ 1 1
    fnCopyfile $SRCBINSDIR/mosquitto_rr $USERBIN_FOLDER/ 1 1
    fnCopyfile $SRCBINSDIR/mosquitto_sub $USERBIN_FOLDER/ 1 1
    fnCopyfile $SRCBINSDIR/mosquitto_ctrl $USERBIN_FOLDER/ 1 1
    fnCopyfile $SRCBINSDIR/mosquitto_passwd $USERBIN_FOLDER/ 1 1

    fnCopyfile $SRCBINSDIR/libmosquitto.so.2.0.11 $USERLIB_FOLDER/ 1 1
    ln -s -f $USERLIB_FOLDER/libmosquitto.so.2.0.11 $USERLIB_FOLDER/libmosquitto.so.1
    ln -s -f $USERLIB_FOLDER/libmosquitto.so.1 $USERLIB_FOLDER/libmosquitto.so
    fnCopyfile $SRCBINSDIR/libmosquittopp.so.2.0.11 $USERLIB_FOLDER/ 1 1
    ln -s -f $USERLIB_FOLDER/libmosquittopp.so.2.0.11 $USERLIB_FOLDER/libmosquittopp.so.1
    ln -s -f $USERLIB_FOLDER/libmosquittopp.so.1 $USERLIB_FOLDER/libmosquittopp.so
fi

#autossh
#if [ $THISARCH = "arm" ]; then
#    echo "******* NOT installing autossh"
#else
#    fnCopyfile $SRCBINSDIR/autossh $USERBIN_FOLDER/ 1 1
#fi

# Softlinks from our bins folder for third-party bins
ln -s -f $USERSBIN_FOLDER/mosquitto $BINSDIR/mosquitto
ln -s -f $USERBIN_FOLDER/redis-server $BINSDIR/redis-server

# template cfg files
# cleanup the old templates and copy new ones
rm -R $TEMPLATES_PROTCFGDIR
cp -R $SRCPROTCFGDIR/templates $PROTCFGDIR/


# Create and configure redis configuration file
# The reason why we want to do it here instead of using a pre-defined redis conf file is -
# we won't know what the redis db file folder is on the target machine (as we won't know
# what is the HOME directory on the target machine)
echo "# data msgQ redis config file created by rmon install script at - $nowdate" > $REDISCFGDIR/redis-rmon.conf
echo "port 19737" >>  $REDISCFGDIR/redis-rmon.conf
echo "protected-mode no" >>  $REDISCFGDIR/redis-rmon.conf
echo "daemonize yes" >> $REDISCFGDIR/redis-rmon.conf
echo "pidfile /var/run/redis_19737.pid" >> $REDISCFGDIR/redis-rmon.conf
echo "databases 1" >> $REDISCFGDIR/redis-rmon.conf
echo "dbfilename redis-msgq-rmon.rdb" >> $REDISCFGDIR/redis-rmon.conf
echo "dir $REDISDBDIR" >> $REDISCFGDIR/redis-rmon.conf
# no snapshotting
echo "save \"\"" >> $REDISCFGDIR/redis-rmon.conf

# remove the old message queues
#rm $REDISDBDIR/*

# Create and configure redis cmds db configuration file
# The reason why we want to do it here instead of using a pre-defined redis conf file is -
# we won't know what the redis db file folder is on the target machine (as we won't know
# what is the HOME directory on the target machine)
echo "# cmds msgQ redis config file created by rmon install script at - $nowdate" > $REDISCFGDIR/redis-cmds-rmon.conf
echo "port 19739" >>  $REDISCFGDIR/redis-cmds-rmon.conf
echo "protected-mode no" >>  $REDISCFGDIR/redis-cmds-rmon.conf
echo "daemonize yes" >> $REDISCFGDIR/redis-cmds-rmon.conf
echo "pidfile /var/run/redis_19739.pid" >> $REDISCFGDIR/redis-cmds-rmon.conf
echo "databases 1" >> $REDISCFGDIR/redis-cmds-rmon.conf
echo "dbfilename redis-cmds-rmon.rdb" >> $REDISCFGDIR/redis-cmds-rmon.conf
echo "dir $REDISDBDIR" >> $REDISCFGDIR/redis-cmds-rmon.conf
# no snapshotting
echo "save \"\"" >> $REDISCFGDIR/redis-cmds-rmon.conf


if [ $THISARCH = "arm" ]; then
    # TODO - we need to understand better what settings we need to do on R501/arm processors
    echo "Not doing LD_LIBRARY_PATH setup..."
    # Note: [ldconfig] command reloads the list of system-wide library paths
    # (this must be run as root and we are root while running this script)
    ldconfig
else
    # We need to put /usr/local/lib/ to LD_LIBRARY_PATH
    # This can be done by adding the following line to /etc/profile file
    #   export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib/
    # This will update the LD_LIBRARY_PATH globally (for all users).
    # It is important that we only want to do it if it is already not there.
    # For that, we check the file to see if the above line already exists.
    if grep -q "export LD_LIBRARY_PATH=\$LD_LIBRARY_PATH:/usr/local/lib/" "/etc/profile"
    then
        # found
        echo "LD_LIBRARY_PATH is already set up. So, no need to update it."
    else
        # not found
        echo "/usr/local/lib/ is not part of LD_LIBRARY_PATH. So, updating it"
        echo "# Uday - added the following line on - $nowdate" >> /etc/profile
        echo "export LD_LIBRARY_PATH=\$LD_LIBRARY_PATH:/usr/local/lib/" >> /etc/profile
    fi
    # Note: [ldconfig] command reloads the list of system-wide library paths
    # (this must be run as root and we are root while running this script)
    ldconfig

    # Giving ownership of the installed folder and all of its children to original user
    echo "chown -R $SUDO_USER $ROOTDIR"
    chown -R $SUDO_USER $ROOTDIR

    echo "Let the current user become part of the dialout group so that serial/usb ports can be accessed"
    usermod -a -G dialout $SUDO_USER

    echo "allowing siec61850-rmon to be able to open tcp port 102 (which is < 1024)"
    sudo setcap 'cap_net_bind_service=+ep' $BINSDIR/siec61850-rmon
    echo "allowing mods-rmon to be able to open tcp port 502 (which is < 1024)"
    sudo setcap 'cap_net_bind_service=+ep' $BINSDIR/mods-rmon
fi

# Setup startup processes
if [ $THISARCH = "arm" ]; then
    echo "Not yet setup the startup stuff!!!"
else
    # exit from root user and add crontab entry in the current user
    # Add watchdog program to crontab
    echo "Setting up watchdog-rmon to run on powerup..."
    # write out current crontab to a temp file
    crontab -u $SUDO_USER -l > ./crontab-rmon-tmp
    # let us remove a line that we used to put in to this file 
    # that starts redis-server on cmd port. We look for "redis-cmds-rmon.conf"
    # substring in the file and remove it.
    sed -i.bak '/redis-cmds-rmon.conf/d' ./crontab-rmon-tmp
    # see if already has [@reboot ~/gw-rmon/bins/watchdog-rmon > /dev/null 2>&1 &] entry in it?
    if grep -q "@reboot ~/gw-rmon/bins/watchdog-rmon" "./crontab-rmon-tmp"
    then
        # found
        echo "watchdog-rmon is already setup to run on powerup. So, no need to update it."
    else
        # not found
        echo "@reboot ~/gw-rmon/bins/watchdog-rmon > /dev/null 2>&1 &" >> ./crontab-rmon-tmp
    fi
    #install new cron file
    crontab -u $SUDO_USER ./crontab-rmon-tmp
    rm ./crontab-rmon-tmp ./crontab-rmon-tmp.bak
fi

echo "Installation Done!"
exit 0
